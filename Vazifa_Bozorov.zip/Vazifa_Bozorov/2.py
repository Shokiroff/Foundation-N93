def counterr(lst):
	dc = {}

	for x in lst:
		if x in dc:
			dc[x] += 1
		else:
			dc[x] = 1

	return dc

lst = [1, 1, 2, 3, 4, 5, 3, 2, 3, 4, 2, 1, 2, 3]
dc = counterr(lst)
print(dc)
