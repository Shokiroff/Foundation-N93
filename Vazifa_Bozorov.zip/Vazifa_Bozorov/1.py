def task1(lst, n):
	return [lst[i:i+n] for i in range(0, len(lst), n)]

lst = ["A","B","C","D","E","F","G","L","Q","U"]
n = int(input("Sonni kiriting:" ))
#print(task1(lst,n))
def task2(sonlar):
	if( int(sonlar[0])+int(sonlar[1])+int(sonlar[2])+int(sonlar[3]) == int(sonlar[4])):
	        return ["+","+","+","="]
	if( int(sonlar[0])-int(sonlar[1])-int(sonlar[2])-int(sonlar[3]) == int(sonlar[4])):
                return ["-","-","-","="]
	if( int(sonlar[0])+int(sonlar[1])+int(sonlar[2])-int(sonlar[3]) == int(sonlar[4])):
                return ["+","+","-","="]
	if( int(sonlar[0])+int(sonlar[1])-int(sonlar[2])+int(sonlar[3]) == int(sonlar[4])):
                return ["+","-","+","="]
	if( int(sonlar[0])-int(sonlar[1])+int(sonlar[2])+int(sonlar[3]) == int(sonlar[4])):
                return ["-","+","+","="]
	if( int(sonlar[0])+int(sonlar[1])-int(sonlar[2])-int(sonlar[3]) == int(sonlar[4])):
       	        return ["+","-","-","="]
	if( int(sonlar[0])-int(sonlar[1])+int(sonlar[2])-int(sonlar[3]) == int(sonlar[4])):
                return ["-","+","-","="]
	if( int(sonlar[0])-int(sonlar[1])-int(sonlar[2])+int(sonlar[3]) == int(sonlar[4])):
                return ["-","-","+","="]
	return "Bu sonlardan hosil qilib bo'lmaydi!"

misol = input()
#print(misol)
sonlar = []
for i in misol:
	if(i.isdigit()):
		sonlar.append(i)
ishora = task2(sonlar)
haqiqiy_misol = sonlar[0]+ishora[0] + sonlar[1]+ishora[1] + sonlar[2]+ishora[2]+sonlar[3]+ishora[3]+sonlar[4]
print(haqiqiy_misol)
