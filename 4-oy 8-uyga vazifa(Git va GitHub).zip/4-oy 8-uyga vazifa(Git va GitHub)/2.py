import os
os.system("clear")

p = input("Ifodani kiriting (masalan, '5 * 4 * 1 * 6 = 2'): ")

e, t = p.split('=')
t = int(t.strip())
numbers = list(map(int, e.split('*')))

def hisoblash(numbers, op):
	result = numbers[0]
	for i in range(len(op)):
		if op[i] == '+':
			result += numbers[i + 1]
		elif op[i] == '-':
			result -= numbers[i + 1]
	return result

def find_op(numbers, t):
	op_list = []
	for i in range(2 ** (len(numbers) - 1)):
		op = ['+'] * (len(numbers) - 1)
		for j in range(len(op)):
			if (i >> j) & 1:
				op[j] = '-'
			if hisoblash(numbers, op) == t:
				return op
	return None

op = find_op(numbers, t)

if op:
	output = []
	print("Natija:")
	for i in range(len(numbers)):
		output.append(str(numbers[i]))
		if i < len(op):
			output.append(op[i])
	output.append('=')
	output.append(str(t))
	print(" ".join(output))

else:
	print("Natija topilmadi.")
