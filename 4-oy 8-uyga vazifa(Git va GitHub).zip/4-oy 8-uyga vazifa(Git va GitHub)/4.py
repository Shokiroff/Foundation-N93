import os
os.system("clear")

cars = [
    {"model": "RDX", "year": 2009},
    {"model": "GLK-Class", "year": 2010},
    {"model": "Express 1500", "year": 2005},
    {"model": "LR2", "year": 2008},
    {"model": "XF", "year": 2005},
    {"model": "Malibu", "year": 2007},
    {"model": "M-Class", "year": 2010},
    {"model": "Routan", "year": 2011}
]
print("\t\tDastlabki ro'yxat:\n")
print(cars,"\n")

sorted_cars = sorted(cars, key = lambda car: car["year"])

ls = []
for car in sorted_cars:
	ls.append(car)
print("\t\tSaralangandan so'ng (yili bo'yicha)\n")
print(ls)
