import os
os.system("clear")
print("\t\tDastlabki ro'yxat")
lst = ["A", "B", "C", "D", "E", "F", "G", "L", "Q", "U"]
print(lst)
n = int(input("Ro'yxatni bo'lish uchun sonni kiriting >>> "))

result = []
print("\t\tBo'lingandan so'ng")
for x in range(0, len(lst), n):
	result.append(lst[x:x + n])
print(result)
