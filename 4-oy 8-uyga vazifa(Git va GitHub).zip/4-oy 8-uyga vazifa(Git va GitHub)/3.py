import os
os.system("clear")

def elements(ls):
	dic = {}
	for x in ls:
		if x in dic:
			dic[x] += 1
		else:
			dic[x] = 1
	return dic

if __name__ == "__main__":

	myList = list(map(int,input("List elementlarini kiriting >>> ").split()))
	print("\nmyList =",myList,"\n")
	result = elements(myList)
	print("myDct =",result)
